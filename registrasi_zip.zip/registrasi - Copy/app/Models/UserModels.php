<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModels extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = ['email', 'password', 'reset_token'];

    public function register($data)
    {
        $this->db->table($this->table)->insert($data);
    }

    public function login($email, $password)
    {
        $user = $this->db->table($this->table)
            ->where('email', $email)
            ->get()
            ->getRowArray();

        if ($user && password_verify($password, $user['password'])) {
            return $user;
        }

        return false;
    }

    public function setPasswordResetToken($email, $token)
    {
        $this->where('email', $email)
            ->set('reset_token', $token)
            ->update();
    }

    public function getUserByToken($token)
    {
        return $this->where('reset_token', $token)
            ->first();
    }
}

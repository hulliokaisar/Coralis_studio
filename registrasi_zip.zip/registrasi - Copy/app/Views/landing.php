<!-- application/views/landing.php -->
<?php include 'templates/header.php'; ?>

<style>
  /* Tambahkan CSS di sini */
  h1 {
    color: blue;
    font-size: 24px;
  }
  p {
    color: green;
    margin-bottom: 10px;
  }
  img {
    max-width: 200px;
    border-radius: 50%;
    margin-bottom: 10px;
  }
</style>

<h1>Welcome to the Landing Page</h1>

<p>Email: <?= $user['email'] ?></p>
<p>Name: <?= $user['name'] ?></p>
<p>Profile Picture: <img src="<?= base_url('uploads/' . $user['profile_picture']) ?>" alt="Profile Picture"></p>

<?php include 'templates/footer.php'; ?>

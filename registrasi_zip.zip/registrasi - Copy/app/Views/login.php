<!-- application/views/login.php -->
<?php include 'templates/header.php'; ?>

<style>
  /* Tambahkan CSS di sini */
  h1 {
    color: blue;
    font-size: 24px;
  }
  .alert {
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ddd;
    background-color: #f9f9f9;
  }
  label {
    display: block;
    margin-top: 10px;
  }
  input[type="email"],
  input[type="password"],
  input[type="submit"] {
    margin-top: 5px;
  }
  p {
    margin-top: 10px;
  }
</style>

<!-- Display success message if available -->
<?php if (session()->getFlashdata('success')): ?>
  <div class="alert alert-success">
    <?= session()->getFlashdata('success') ?>
  </div>
<?php endif; ?>

<h1>Login</h1>

<form method="POST" action="<?= base_url('auth/login') ?>">
<?= csrf_field(); ?>
  <label for="email">Email:</label>
  <input type="email" name="email" id="email" required><br>

  <label for="password">Password:</label>
  <input type="password" name="password" id="password" required><br>

  <input type="submit" value="Login">
</form>

<p>Belum punya akun? <a href="<?= base_url('auth/register') ?>">Registrasi</a></p>
<p>Lupa password? <a href="<?= base_url('auth/forgot_password') ?>">Ubah</a></p>

<?php include 'templates/footer.php'; ?>

<!-- application/views/registration.php -->
<?php include 'templates/header.php'; ?>

<style>
  /* Tambahkan CSS di sini */
  h1 {
    color: blue;
    font-size: 24px;
  }
  label {
    display: block;
    margin-top: 10px;
  }
  input[type="email"],
  input[type="text"],
  input[type="password"],
  input[type="file"],
  input[type="submit"] {
    margin-top: 5px;
  }
  span {
    display: block;
    margin-top: 5px;
  }
</style>

<h1>Registration</h1>

<form method="POST" action="<?= base_url('auth/register') ?>" enctype="multipart/form-data">
  <?= csrf_field(); ?>
  <label for="email">Email:</label>
  <input type="email" name="email" id="email" required><br>

  <label for="name">Name:</label>
  <input type="text" name="name" id="name" required><br>

  <label for="password">Password:</label>
  <input type="password" name="password" id="password" required><br>

  <label for="profile_picture">Profile Picture:</label>
  <span>Upload max: 5 MB</span>
  <input type="file" name="profile_picture" id="profile_picture" required><br>

  <input type="submit" value="Register">
</form>

<p>Belum punya akun? <a href="<?= base_url('auth/login') ?>">Login</a></p>

<?php include 'templates/footer.php'; ?>

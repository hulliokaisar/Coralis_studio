<!-- application/views/forgot_password.php -->
<?php include 'templates/header.php'; ?>

<style>
  /* Tambahkan CSS di sini */
  h1 {
    color: blue;
    font-size: 24px;
  }
  .error {
    color: red;
    font-weight: bold;
  }
  .success {
    color: green;
    font-weight: bold;
  }
  label {
    display: block;
    margin-top: 10px;
  }
  input[type="email"],
  input[type="password"],
  input[type="submit"] {
    margin-top: 5px;
  }
</style>

<h1>Forgot Password</h1>

<?php if (session()->getFlashdata('error')): ?>
  <div class="error">
    <?= session()->getFlashdata('error') ?>
  </div>
<?php endif; ?>

<?php if (session()->getFlashdata('success')): ?>
  <div class="success">
    <?= session()->getFlashdata('success') ?>
  </div>
<?php endif; ?>

<form method="POST" action="<?= base_url('auth/forgot_password') ?>">
<?= csrf_field(); ?>
  <label for="email">Email:</label>
  <input type="email" name="email" id="email" required><br>

  <label for="new_password">New Password:</label>
  <input type="password" name="new_password" id="new_password" required><br>

  <label for="repeat_new_password">Repeat New Password:</label>
  <input type="password" name="repeat_new_password" id="repeat_new_password" required><br>

  <input type="submit" value="Reset Password">
</form>

<?php include 'templates/footer.php'; ?>

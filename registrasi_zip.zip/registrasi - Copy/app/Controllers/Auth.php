<?php

namespace App\Controllers;

use App\Models\UserModels;
use CodeIgniter\Controller;
use Config\Services;

class Auth extends Controller
{
    public function login()
    {
        $model = new UserModels();
        helper('form');

        $validation = Services::validation();
        $validation->setRules([
            'email' => 'required|valid_email',
            'password' => 'required'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return view('login');
        } else {
            $email = $this->request->getVar('email');
            $password = $this->request->getVar('password');

            $user = $model->login($email, $password);

            if ($user) {
                session()->set('user', $user);

                return redirect()->to('home/landing');
            } else {
                $data['error'] = 'Invalid email or password';
                return view('login', $data);
            }
        }
    }

    public function register()
    {
        $model = new UserModels();
        helper('form');

        $validation = Services::validation();
        $validation->setRules([
            'email' => 'required|valid_email',
            'name' => 'required',
            'password' => 'required',
            'profile_picture' => 'uploaded[profile_picture]|mime_in[profile_picture,image/jpg,image/jpeg,image/png]|max_size[profile_picture,5000]'
        ]);

        if (!$validation->withRequest($this->request)->run()) {
            return view('registration');
        } else {
            $upload = $this->uploadPicture();

            if ($upload) {
                $data = [
                    'email' => $this->request->getVar('email'),
                    'name' => $this->request->getVar('name'),
                    'password' => password_hash($this->request->getVar('password'), PASSWORD_DEFAULT),
                    'profile_picture' => $this->request->getFile('profile_picture')->getName()
                ];

                $model->register($data);

                return redirect()->to(site_url('auth/login'));
            } else {
                $data['error'] = $validation->getError('profile_picture');
                return view('registration', $data);
            }
        }
    }

    public function uploadPicture()
    {
        $validation = Services::validation();
        $file = $this->request->getFile('profile_picture');

        if ($file->isValid()) {
            if ($file->move('./uploads/', $file->getRandomName())) {
                return true;
            } else {
                $validation->setRule('profile_picture', 'Profile Picture', 'uploaded[profile_picture]');
            }
        } else {
            $validation->setRule('profile_picture', 'Profile Picture', 'uploaded[profile_picture]');
        }

        return false;
    }


    public function forgot_password()
  {
    $model = new UserModels();
    helper(['form']);

    $validation = Services::validation();
    $validation->setRules([
      'email' => 'required|valid_email',
      'new_password' => 'required',
      'repeat_new_password' => 'required|matches[new_password]'
    ]);

    if (!$validation->withRequest($this->request)->run()) {
      return view('forgot_password');
    } else {
      $email = $this->request->getVar('email');
      $newPassword = $this->request->getVar('new_password');
      $repeatNewPassword = $this->request->getVar('repeat_new_password');

      // Check if the email exists in the database
      $user = $model->where('email', $email)->first();
      if ($user === null) {
        session()->setFlashdata('error', 'Email not found.');
        return view('forgot_password');
      }

      // Update the password in the database
      $data = [
        'password' => password_hash($newPassword, PASSWORD_DEFAULT)
      ];
      $model->update($user['id'], $data);

      session()->setFlashdata('success', 'Password has been updated.');

      return redirect()->to(site_url('auth/login'));
    }
  }
}

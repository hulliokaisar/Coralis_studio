<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class Home extends Controller {
  public function landing() {
    $session = session();
    $user = $session->get('user');

    if ($user) {
      $data['user'] = $user;
      return view('landing', $data);
    } else {
      return redirect()->to('auth/login');
    }
  }
}
